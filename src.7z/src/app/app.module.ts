import { NgModule } from '@angular/core';
import { IonicApp, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { InwestycjePage } from '../pages/inwestycje/inwestycje';
import { MenuPage } from '../pages/menu/menu';
import { PracaPage } from '../pages/praca/praca';
import { ResetPasswordPage } from '../pages/reset-password/reset-password';
import { SignupPage } from '../pages/signup/signup';
import { MyTabPage } from '../pages/my-tab-page/my-tab-page';
import { StartPage } from '../pages/start/start'
import { ProfilePage } from '../pages/profile/profile';
// Importing provider
import { AuthData } from '../providers/auth-data';
import { ProfileData } from '../providers/profile-data';
import { Data } from '../providers/data';
// Import the AF2 Module
import { AngularFireModule, AuthProviders, AuthMethods } from 'angularfire2';

// AF2 Settings
export const firebaseConfig = {
  apiKey: "AIzaSyDT3wG5uaXASLyIlkSYLXFxOZjw7hE7_78",
  authDomain: "ionic-firebase-auth-12bf4.firebaseapp.com",
  databaseURL: "https://ionic-firebase-auth-12bf4.firebaseio.com",
  storageBucket: "ionic-firebase-auth-12bf4.appspot.com",
  messagingSenderId: "249749518748"
};

const myFirebaseAuthConfig = {
  provider: AuthProviders.Password,
  method: AuthMethods.Password
}

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    InwestycjePage,
    MenuPage,
    PracaPage,
    LoginPage,
    ResetPasswordPage,
    SignupPage,
    MyTabPage,
    StartPage,
    ProfilePage
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(firebaseConfig, myFirebaseAuthConfig)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    InwestycjePage,
    MenuPage,
    PracaPage,
    LoginPage,
    ResetPasswordPage,
    SignupPage,
    MyTabPage,
    StartPage,
    ProfilePage
  ],
  providers: [AuthData, ProfileData, Data]
})
export class AppModule {}
