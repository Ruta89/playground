import { Component } from '@angular/core';
import { NavController, AlertController, ActionSheetController } from 'ionic-angular';
import { AngularFire, FirebaseListObservable } from 'angularfire2';
import { MenuPage } from '../menu/menu';
import { ProfilePage } from '../profile/profile';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    songs: FirebaseListObservable<any>;


    constructor(public navCtrl: NavController, af: AngularFire, public AlertCtrl: AlertController, public actionSheetCtrl: ActionSheetController) {
        this.songs = af.database.list('/songs');
    }

    goToMenu(){
      this.navCtrl.push(MenuPage);
    }

    goToProfile(){
      this.navCtrl.push(ProfilePage);
    }



    addSong() {
        let prompt = this.AlertCtrl.create({
            title: 'Nazwa piosenki',
            message: 'Wpisz swoja ulubiona piosenkę',
            inputs: [
                {
                    name: 'title',
                    placeholder: 'Tytul'
                },
            ],
            buttons: [
                {
                    text: 'Anuluj',
                    handler: data => {
                        console.log('Anuluj klikniecie');
                    }
                },
                {
                    text: 'Zapisz',
                    handler: data => {
                        this.songs.push({
                            title: data.title
                        });
                    }
                }
            ]
        });
        prompt.present();
    }

    removeSong(songId: string) {
        this.songs.remove(songId);
    }

    updateSong(songId, songTitle) {
        let prompt = this.AlertCtrl.create({
            title: 'Nazwa piosenki',
            message: 'Zakutalizuj tą piosekę',
            inputs: [
                {
                    name: 'title',
                    placeholder: "Tytul",
                    value: songTitle
                },
            ],
            buttons: [
              {
                text: 'Anuluj',
                handler: data => {
                  console.log('Kliknales Anuluj');
                }
              },
              {
                text: 'Save',
                handler: data => {
                  this.songs.update(songId, {
                    title: data.title
                  });
                }
              }
            ]
        });
        prompt.present();
    }

    showOptions(songId, songTitle) {
        let actionSheet = this.actionSheetCtrl.create({
            title: 'Co chcesz zrobić?',
            buttons: [
                {
                    text: 'Usuń piosenkę',
                    role: 'destructive',
                    handler: () => {
                        this.removeSong(songId);
                    }
                }, {
                    text: 'Uaktualnij Tytul',
                    handler: () => {
                        this.updateSong(songId, songTitle);
                    }
                }, {
                    text: 'Anuluj',
                    role: 'cancel',
                    handler: () => {
                        console.log('Kliknales Anuluj');
                    }
                }
            ]
        });
        actionSheet.present();
    }

}
