import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { InwestycjePage } from '../inwestycje/inwestycje';
import { HomePage } from '../home/home';
import { PracaPage } from '../praca/praca';
import { StartPage } from '../start/start';
import { Data } from '../../providers/data';
import { ProfilePage } from '../profile/profile';
import { LoginPage } from '../login/login';
import { SignupPage } from '../signup/signup';
import { ResetPasswordPage } from '../reset-password/reset-password';
import { MyTabPage } from '../my-tab-page/my-tab-page';

@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html'
})
export class MenuPage {
companies: any;
  constructor(public navCtrl: NavController, public data: Data) {
    this.data.loadAll().then(result => {
      this.companies = result;
    })
  }

  goToInwestycje(){
    this.navCtrl.push(InwestycjePage);
  }

  goToPraca(){
    this.navCtrl.push(PracaPage);
  }

  goToHome(){
    this.navCtrl.push(HomePage);
  }

  goToStart(){
    this.navCtrl.push(StartPage);
  }

  goToProfile(){
    this.navCtrl.push(ProfilePage);
  }

  goToLogin(){
    this.navCtrl.push(LoginPage);
  }

  goToResetPassword(){
    this.navCtrl.push(ResetPasswordPage);
  }

  goToSignup(){
    this.navCtrl.push(SignupPage);
  }
  goToTab(){
    this.navCtrl.push(MyTabPage);
  }

  ionViewDidLoad() {
    console.log('Hello MenuPage Page');
  }

}
