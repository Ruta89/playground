import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';
import { ProfileData } from '../../providers/profile-data';
import { AuthData } from '../../providers/auth-data';
import { LoginPage } from '../login/login';

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html'
})
export class ProfilePage {
public userProfile: any;
public birthDate: string;

  constructor(public navCtrl: NavController, public profileData: ProfileData,
      public authData: AuthData, public alertCtrl: AlertController) {
        this.navCtrl = navCtrl;
        this.profileData = profileData;


        this.profileData.getUserProfile().on('value', (data) => {
        this.userProfile = data.val();
        this.birthDate = this.userProfile.birthDate;
      });
  }

  ionViewDidLoad() {
    console.log('Hello ProfilePage Page');
  }

  logOut(){
    this.authData.logoutUser().then(() => {
      this.navCtrl.setRoot(LoginPage);
    });
  }

  updateName(){
    let alert = this.alertCtrl.create({
      message: "Twoje imie i nazwisko",
      inputs: [
        {
          name: 'firstName',
          placeholder: 'Twoje imię',
          value: this.userProfile.firstName
        },
        {
          name: 'lastName',
          placeholder: 'Twoje nazwisko',
          value: this.userProfile.lastName
        },
      ],
      buttons: [
        {
          text: 'Anuluj',
        },
        {
          text: 'Zapisz',
          handler: data => {
            this.profileData.updateName(data.firstName, data.lastName);
          }
        }
      ]
    });
    alert.present();
  }

  updateDOB(birthDate){
    this.profileData.updateDOB(birthDate);
  }

  updateEmail(){
    let alert = this.alertCtrl.create({
      inputs: [
        {
          name: 'newEmail',
          placeholder: 'Twoj email',
        },
      ],
      buttons: [
        {
          text: 'Anuluj',
        },
        {
          text: 'Zapisz',
          handler: data => {
            this.profileData.updateEmail(data.newEmail);
          }
        }
      ]
    });
    alert.present();
  }

  updatePassword(){
    let alert = this.alertCtrl.create({
      inputs: [
        {
          name: 'newPassword',
          placeholder: 'Twoje nowe haslo',
          type: 'password'
        },
      ],
      buttons: [
        {
          text: 'Anuluj',
        },
        {
          text: 'Zapisz',
          handler: data => {
            this.profileData.updatePassword(data.newPassword);
          }
        }
      ]
    });
    alert.present();
  }

}
