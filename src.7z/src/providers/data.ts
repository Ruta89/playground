import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class Data {
data: any;
  constructor(public http: Http) {
    console.log('Hello Data Provider');
    this.data = [
      {name: 'Seat', code: 324, product: 'Ibiza'},
      {name: 'Fiat', code: 111, product: 'Tipo'},
      {name: 'Seat', code: 222, product: 'Cordoba'},
      {name: 'Seasdat', code: 666, product: 'Ibigza'},
      {name: 'Seasfdat', code: 999, product: 'Ibihgza'},
      {name: 'Sefadsat', code: 374, product: 'Ibddiza'},
      {name: 'Seadsfat', code: 924, product: 'Ibaaiza'}
    ];
  }

  loadAll(){
    return Promise.resolve(this.data);
  }

}
